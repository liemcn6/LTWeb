<?php
    $title = 'MÁY TÍNH BẢNG';
	$baseUrl = '../../../';
    $UrlCartView = '../../..';
    $product_type = 'SAMSUNG';
    $product_type_url = '../';
    include_once('../maytinhbang-main.php');
?>
<style> 
    .product-type a:nth-child(2) span {
        background-color: #ddd;
    }
</style>