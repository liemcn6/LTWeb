<?php
    $title = 'MÁY TÍNH BẢNG';
	$baseUrl = '../../../';
    $UrlCartView = '../../..';
    $product_type = 'Huawei';
    $product_type_url = '../';
    include_once('../maytinhbang-main.php');
?>
<style> 
    .product-type a:nth-child(4) span {
        background-color: #ddd;
    }
</style>