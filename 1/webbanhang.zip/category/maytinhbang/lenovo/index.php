<?php
    $title = 'MÁY TÍNH BẢNG';
	$baseUrl = '../../../';
    $UrlCartView = '../../..';
    $product_type = 'Lenovo';
    $product_type_url = '../';
    include_once('../maytinhbang-main.php');
?>
<style> 
    .product-type a:nth-child(3) span {
        background-color: #ddd;
    }
</style>