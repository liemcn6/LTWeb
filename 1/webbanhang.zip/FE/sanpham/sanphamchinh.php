<div class="grid wide" id="main-product-a">
    <div class="main-product" >
        <a href="category/dienthoai" class="tag-a">
            <div class="main-product1">
                <div class="main-procduct1-1 main-product-chung">
                    <div class="main-product-overlay"></div>
                </div>
                <div class="main-product-name">
                    <span>ĐIỆN THOẠI</span>
                    <span class="main-reduce-price">Giảm 50%</span>
                </div>
            </div>
        </a>
        <a href="category/maytinhbang" class="tag-a">
            <div class="main-product2">
                <div class="main-procduct2-2 main-product-chung">
                    <div class="main-product-overlay"></div>
                </div>
                <div class="main-product-name">
                    <span>MÁY TÍNH BẢNG</span>
                    <span class="main-reduce-price">Giảm 10%</span>
                </div>
            </div>
        </a>
        <a href="category/phukien/?page=1" class="tag-a">
            <div class="main-product3">
                <div class="main-procduct3-3 main-product-chung">
                    <div class="main-product-overlay"></div>
                </div>
                <div class="main-product-name">
                    <span>TAI NGHE</span>
                    <span class="main-reduce-price">Giảm 20%</span>
                </div>
            </div>
        </a>
    </div>
</div>