<div class="section-bg-phone">
    <div class="section-bg"></div>
    <div class="section-description">
        <span class="big-img-birth">SIÊU SALE CHÚC MỪNG SINH NHẬT</span>
        <span class="big-img-name-product">Apple Watch Series 5</span>
        <span class="big-img-time-sale">Giảm ngay 1 triệu động từ 15/9-31/9</span>
        <a href="category/sanpham/sp.php?sp=199" class="tag-a">
            <button class="btn-bg ">Xem ngay <i class="fas fa-chevron-right"></i></button>
        </a>
    </div>
    <a href="#main-product-a" class="tag-a"><i class="fas fa-chevron-down bg-down"></i></a>
</div>