<div class="masthead-search">
    <div class="masthead-search-box">
        <form action="" class="header-search-form">
            <input type="text" placeholder="Tìm kiếm điện thoại, laptop" class="header-search-input">
            <button type="submit" class="header-search-icon">
                <i class="fas fa-search"></i>
            </button>
        </form>
    </div>
</div>