<?php
	$title = 'Quản lý chung';
	$baseUrl = '';
	require_once($baseUrl.'layouts/header.php');
	
?>
<style> 
	.nav-item:nth-child(1) {
		background-color: #c1c1c1;
	}
</style>
<div class="row">
	<div class="col-md-12">
		<h1>Quản lý chung</h1>
	</div>
</div>

<?php
	require_once($baseUrl.'layouts/footer.php');
?>